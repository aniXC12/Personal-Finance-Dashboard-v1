import { NextResponse } from "next/server";
import { withCategories } from "@/lib/categorize";

// Accepts text/csv in the body. CSV header: date,description,amount,account
export async function POST(req: Request) {
  const text = await req.text();
  const lines = text.split(/\r?\n/).filter(Boolean);
  const [header, ...rows] = lines;
  const cols = header.toLowerCase().split(",").map(s => s.trim());
  const dateIdx = cols.indexOf("date");
  const descIdx = cols.indexOf("description");
  const amtIdx = cols.indexOf("amount");
  const acctIdx = cols.indexOf("account");

  if (dateIdx === -1 || descIdx === -1 || amtIdx === -1) {
    return NextResponse.json({ error: "CSV must include date, description, amount[, account]" }, { status: 400 });
  }

  const txns = rows.map((r, i) => {
    const parts = r.split(",").map(s => s.trim());
    const amount = Number(parts[amtIdx]);
    return {
      id: String(i + 1),
      date: parts[dateIdx],
      description: parts[descIdx],
      amount: isNaN(amount) ? 0 : amount,
      account: acctIdx !== -1 ? parts[acctIdx] : undefined
    };
  });

  return NextResponse.json(withCategories(txns));
}
