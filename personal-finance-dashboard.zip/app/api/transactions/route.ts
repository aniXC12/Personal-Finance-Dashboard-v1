import { NextResponse } from "next/server";
import { withCategories } from "@/lib/categorize";
import { sampleTxns } from "@/lib/sampleData";

export async function GET() {
  // Return sample data for quick demo
  return NextResponse.json(withCategories(sampleTxns));
}
