"use client";

import { useEffect, useMemo, useState } from "react";
import TransactionsTable from "@/components/TransactionsTable";
import Upload from "@/components/Upload";
import Charts from "@/components/Charts";
import Stat from "@/components/Stat";
import type { Txn } from "@/lib/categorize";

export default function Page() {
  const [rows, setRows] = useState<Txn[]>([]);
  const [loading, setLoading] = useState(true);
  const [goal, setGoal] = useState(500); // monthly savings goal

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/transactions");
      const data = await res.json();
      setRows(data);
      setLoading(false);
    })();
  }, []);

  const spend = useMemo(() => rows.filter(r => r.amount < 0).reduce((s, r) => s + r.amount, 0), [rows]);
  const income = useMemo(() => rows.filter(r => r.amount > 0).reduce((s, r) => s + r.amount, 0), [rows]);
  const net = income + spend;

  return (
    <main className="container py-8 space-y-6">
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="h1">Personal Finance Dashboard</div>
          <div className="text-white/70">Upload CSV or start with sample data. Visualize spend, income, and goals.</div>
        </div>
        <div className="flex items-center gap-3">
          <a href="https://github.com/new" className="button-ghost">Fork &amp; Star</a>
          <a href="https://vercel.com/new" className="button">Deploy</a>
        </div>
      </header>

      <div className="card">
        <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-6">
          <Upload onData={setRows} />
          <button className="button-ghost" onClick={async () => {
            setLoading(true);
            const res = await fetch("/api/transactions");
            const data = await res.json();
            setRows(data);
            setLoading(false);
          }}>Use Sample Data</button>
          <div className="flex items-center gap-2 ml-auto">
            <span className="badge">Savings goal (monthly)</span>
            <input className="input w-28 text-right" type="number" value={goal} onChange={e => setGoal(Number(e.target.value || 0))} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Stat label="Income (month)" value={`$${income.toFixed(2)}`} />
        <Stat label="Spend (month)" value={`$${(-spend).toFixed(2)}`} />
        <Stat label="Net (month)" value={`$${net.toFixed(2)}`} />
      </div>

      <Charts rows={rows} />

      <TransactionsTable rows={rows} />

      <footer className="text-white/50 text-xs text-center py-6">
        Built with Next.js, Tailwind, and Recharts. CSV schema: date, description, amount[, account].
      </footer>

      {loading && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center">
          <div className="card">Loading…</div>
        </div>
      )}
    </main>
  );
}
